#include "BonusDmg.hpp"

BonusDmg::BonusDmg() : Item("Bonus Dmg") {
	this->amount = 50;
}

void BonusDmg::activate(Entity* target) {
	target->damage(this->amount);
}
